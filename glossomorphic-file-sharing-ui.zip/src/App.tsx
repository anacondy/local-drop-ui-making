import { useState, useCallback } from 'react';
import { motion, AnimatePresence, type PanInfo } from 'framer-motion';
import StatusBar from './components/StatusBar';
import HeaderBar from './components/HeaderBar';
import ModeToggle from './components/ModeToggle';
import QRCodeView from './components/QRCodeView';
import ScannerView from './components/ScannerView';
import PlatformRow from './components/PlatformRow';
import ConnectedDevices from './components/ConnectedDevices';
import type { Device } from './components/ConnectedDevices';

const MOCK_DEVICES: Device[] = [
  { id: '1', name: 'Pixel 8 Pro', platform: 'android', ip: '192.168.1.102' },
  { id: '2', name: 'MacBook Air', platform: 'macos', ip: '192.168.1.105' },
  { id: '3', name: 'iPhone 15', platform: 'ios', ip: '192.168.1.108' },
];

const NETWORK_IP = '192.168.1.100';
const PORT = 5001;

export default function App() {
  const [mode, setMode] = useState<'qr' | 'scan'>('qr');
  const [devices, setDevices] = useState<Device[]>(MOCK_DEVICES);
  const [direction, setDirection] = useState(0);

  const handleModeToggle = useCallback((newMode: 'qr' | 'scan') => {
    setDirection(newMode === 'scan' ? 1 : -1);
    setMode(newMode);
  }, []);

  const handleSwipe = useCallback(
    (_: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
      const threshold = 50;
      if (info.offset.x < -threshold && mode === 'qr') {
        setDirection(1);
        setMode('scan');
      } else if (info.offset.x > threshold && mode === 'scan') {
        setDirection(-1);
        setMode('qr');
      }
    },
    [mode]
  );

  const toggleDevice = useCallback(() => {
    setDevices((prev) => {
      if (prev.length >= 3) return [];
      return MOCK_DEVICES.slice(0, prev.length + 1);
    });
  }, []);

  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 300 : -300,
      opacity: 0,
      scale: 0.9,
      rotateY: dir > 0 ? 8 : -8,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
      rotateY: 0,
    },
    exit: (dir: number) => ({
      x: dir > 0 ? -300 : 300,
      opacity: 0,
      scale: 0.9,
      rotateY: dir > 0 ? -8 : 8,
    }),
  };

  return (
    <div className="h-full w-full bg-gloss-bg flex justify-center items-center">
      {/* Outer glow container */}
      <div className="w-full max-w-[430px] h-full flex flex-col relative overflow-hidden">
        {/* Status Bar */}
        <StatusBar />

        {/* Header */}
        <HeaderBar title="AirBridge" />

        {/* Supported Platforms Row */}
        <div className="mt-1">
          <PlatformRow />
        </div>

        {/* Mode Toggle */}
        <div className="mt-3">
          <ModeToggle mode={mode} onToggle={handleModeToggle} />
        </div>

        {/* Main Swipeable Content Area */}
        <div
          className="flex-1 relative overflow-hidden mt-1"
          style={{ perspective: '1200px' }}
        >
          <AnimatePresence initial={false} custom={direction} mode="wait">
            <motion.div
              key={mode}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                type: 'spring',
                stiffness: 300,
                damping: 30,
                mass: 0.8,
              }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.15}
              onDragEnd={handleSwipe}
              className="absolute inset-0 flex items-start justify-center pt-2"
              style={{ touchAction: 'pan-y' }}
            >
              {mode === 'qr' ? (
                <QRCodeView networkIP={NETWORK_IP} port={PORT} />
              ) : (
                <ScannerView />
              )}
            </motion.div>
          </AnimatePresence>

          {/* Page indicator dots */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 z-10">
            <motion.div
              animate={{
                width: mode === 'qr' ? 20 : 8,
                backgroundColor: mode === 'qr' ? '#1c1c1e' : '#c7c7cc',
              }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="h-2 rounded-full"
            />
            <motion.div
              animate={{
                width: mode === 'scan' ? 20 : 8,
                backgroundColor: mode === 'scan' ? '#1c1c1e' : '#c7c7cc',
              }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="h-2 rounded-full"
            />
          </div>
        </div>

        {/* Bottom Section */}
        <div className="shrink-0">
          {/* Simulate Connection Button */}
          <div className="flex justify-center pb-3">
            <motion.button
              onClick={toggleDevice}
              whileTap={{ scale: 0.95 }}
              className="gloss-dark-pill text-white text-[12px] font-semibold px-6 py-3 rounded-2xl flex items-center gap-2.5"
            >
              <div className="w-5 h-5 rounded-lg bg-white/15 flex items-center justify-center">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
                  <path d="M12 5v14M5 12h14" />
                </svg>
              </div>
              {devices.length >= 3 ? 'Reset Connections' : 'Simulate Connection'}
            </motion.button>
          </div>

          <ConnectedDevices devices={devices} networkName="AirBridge_Local" />

          {/* Home indicator */}
          <div className="flex justify-center pb-3 pt-1">
            <div className="w-[134px] h-[5px] rounded-full bg-gloss-dark/20" />
          </div>
        </div>
      </div>
    </div>
  );
}
